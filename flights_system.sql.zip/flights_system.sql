--
-- Database: `flights_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `airlines`
--

CREATE TABLE `airlines` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `code` varchar(50) NOT NULL,
  `logo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `airports`
--

CREATE TABLE `airports` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) NOT NULL,
  `code` varchar(50) NOT NULL,
  `city_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `airports`
--

INSERT INTO `airports` (`id`, `name`, `code`, `city_name`) VALUES
(1, 'Madrid Barajas', 'MAD', 'Madrid'),
(3, 'Changi', 'SIN', 'Singapore');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) NOT NULL,
  `flight_id` int(10) NOT NULL,
  `num_tickets` smallint(6) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `flight_id`, `num_tickets`) VALUES
(3, 1, 3, 20),
(4, 1, 4, 20),
(6, 2, 4, 20),
(7, 2, 4, 20),
(8, 2, 2, 20),
(9, 2, 2, 20),
(10, 1, 1, 1),
(11, 1, 1, 1),
(12, 1, 1, 1),
(13, 1, 2, 1),
(14, 1, 3, 1),
(15, 1, 4, 1),
(16, 1, 5, 1),
(17, 1, 4, 1),
(18, 1, 4, 1),
(19, 1, 4, 1),
(20, 1, 3, 1),
(21, 1, 5, 1),
(22, 1, 4, 1),
(23, 1, 5, 1),
(24, 1, 4, 1),
(25, 1, 5, 1),
(26, 1, 5, 1),
(27, 1, 5, 1),
(28, 1, 5, 1),
(29, 1, 4, 1),
(30, 1, 5, 1),
(31, 1, 5, 1),
(32, 1, 5, 1),
(33, 1, 2, 1),
(34, 1, 2, 1),
(35, 1, 5, 1),
(36, 1, 5, 1),
(37, 1, 5, 1),
(38, 1, 5, 1),
(39, 1, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

CREATE TABLE `flights` (
  `id` int(10) UNSIGNED NOT NULL,
  `flight_no` varchar(10) NOT NULL,
  `flight_from` varchar(50) NOT NULL,
  `flight_to` varchar(50) NOT NULL,
  `departure_time` datetime NOT NULL,
  `arrival_time` datetime NOT NULL,
  `price` smallint(5) UNSIGNED NOT NULL,
  `economy_seats` smallint(5) UNSIGNED NOT NULL,
  `business_seats` smallint(6) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`id`, `flight_no`, `flight_from`, `flight_to`, `departure_time`, `arrival_time`, `price`, `economy_seats`, `business_seats`) VALUES
(2, 'BA200', 'MAD', 'SIN', '2015-11-20 00:00:00', '2015-11-20 05:00:00', 200, 100, 150),
(3, 'E200', 'Sierra Leone', 'Beijing', '2015-11-20 00:00:00', '2015-11-20 01:00:00', 300, 20, 30),
(4, 'R190', 'MAD', 'SIN', '2015-11-20 00:00:00', '2015-11-20 00:00:00', 400, 30, 40),
(5, 'R190', 'MAD', 'SIN', '2015-11-20 00:00:00', '2015-11-20 00:00:00', 400, 30, 40);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `phone_num` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `phone_num`, `email`, `password`) VALUES
(1, 'Ada', 'Lungu', '999', 'a@a', '999'),
(2, 'Jim', 'Carsom', '3511', 'j@c', '333'),
(3, 'James', 'Kan', '345', 'j@k', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `airlines`
--
ALTER TABLE `airlines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `airports`
--
ALTER TABLE `airports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flights`
--
ALTER TABLE `flights`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `airlines`
--
ALTER TABLE `airlines`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `airports`
--
ALTER TABLE `airports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT for table `flights`
--
ALTER TABLE `flights`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
